﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Assessment4MVCEF.Entities;

public partial class AssessmentEfContext : DbContext
{
    public AssessmentEfContext()
    {
    }

    public AssessmentEfContext(DbContextOptions<AssessmentEfContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Company1> Company1s { get; set; }

    public virtual DbSet<Student1> Student1s { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=DESKTOP-MMAT251\\SQLEXPRESS01;Initial Catalog=AssessmentEF;Integrated Security=True;Trust Server Certificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Company1>(entity =>
        {
            entity.HasKey(e => e.CompanyId).HasName("PK__Company1__2D971CAC1FDEA62D");

            entity.ToTable("Company1");

            entity.Property(e => e.CompanyId).ValueGeneratedNever();
            entity.Property(e => e.Address)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.City)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.Name)
                .HasMaxLength(40)
                .IsUnicode(false);
        });

        modelBuilder.Entity<Student1>(entity =>
        {
            entity.HasKey(e => e.StudentId).HasName("PK__Student1__32C52B993152E4F7");

            entity.ToTable("Student1");

            entity.Property(e => e.StudentId).ValueGeneratedNever();
            entity.Property(e => e.Name)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.Qualification)
                .HasMaxLength(40)
                .IsUnicode(false);
            entity.Property(e => e.Skill)
                .HasMaxLength(40)
                .IsUnicode(false);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
