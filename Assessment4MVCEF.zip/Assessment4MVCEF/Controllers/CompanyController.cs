﻿using Assessment4MVCEF.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Assessment4MVCEF.Controllers
{
    public class CompanyController : Controller
    {
        private readonly AssessmentEfContext obj = new AssessmentEfContext();
        public IActionResult Index()
        {
            var companies = obj.Company1s;
            return View(companies);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // Add a company (POST)
        [HttpPost]
        public IActionResult Create(Company1 company)
        {
            if (ModelState.IsValid)
            {
                obj.Company1s.Add(company);
                obj.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View(company);

            }
            
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var Companies = obj.Company1s.FirstOrDefault(c => c.CompanyId == id);
            if (Companies == null)
            {
                return NotFound();
            }
            return View(Companies);
        }
        [HttpPost]
        public IActionResult Edit(Company1 company)
        {
            if (ModelState.IsValid)
            {
                obj.Company1s.Add(company);
                obj.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View(company);
            }
        }
        [HttpGet]
        public IActionResult Details(int id)
        {
            var companies = obj.Company1s.FirstOrDefault(c => c.CompanyId == id);
            if (companies == null)
            {
                return NotFound();
            }
            return View(companies);
        }
        public IActionResult Delete(int id)
        {
            var companies = obj.Company1s.FirstOrDefault(c => c.CompanyId == id);
            if (companies == null)
            {
                return NotFound();
            }
            return View(companies);
        }

        // Delete a student (POST)
        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            var companies = obj.Company1s.FirstOrDefault(c => c.CompanyId == id);
            if (companies != null)
            {
                obj.Company1s.Remove(companies);
                obj.SaveChanges();
            }
            return RedirectToAction("Index");
        }
    }
}
