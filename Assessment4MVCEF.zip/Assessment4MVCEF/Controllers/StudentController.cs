﻿using Assessment4MVCEF.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;    

namespace Assessment4MVCEF.Controllers
{
    public class StudentController : Controller
    {
        private readonly AssessmentEfContext obj = new AssessmentEfContext();
        [HttpGet]
        public IActionResult Index()
        {
            var students = obj.Student1s;     
            return View(students);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Student1 student)
        {
            if (ModelState.IsValid)
            {
                obj.Student1s.Add(student);
                obj.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(student);
        }
        
        // Get student details by studentId
        [HttpGet]
        public IActionResult Details(int id)
        {
            var student = obj.Student1s.FirstOrDefault(s => s.StudentId == id);
            if (student == null)
            {
                return NotFound();
            }
            return View(student);
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var student = obj.Student1s.FirstOrDefault(s => s.StudentId == id);
            if (student == null)
            {
                return NotFound();
            }
            return View(student);
        }

        // Edit a student (POST)
        [HttpPost]
        public IActionResult Edit(Student1 student)
        {
            if (ModelState.IsValid)
            {
                obj.Student1s.Update(student);
                obj.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(student);
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var student = obj.Student1s.FirstOrDefault(s => s.StudentId == id);
            if (student == null)
            {
                return NotFound();
            }
            return View(student);
        }

        // Delete a student (POST)
        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            var student = obj.Student1s.FirstOrDefault(s => s.StudentId == id);
            if (student != null)
            {
                obj.Student1s.Remove(student);
                obj.SaveChanges();
            }
            return RedirectToAction("Index");
        }
    }
}
